from machine import Pin, ADC
import time
import dht

import network as MOD_NETWORK
import time as MOD_TIME
import os as MOD_OS

'''
Đèn thông minh
    - Led xanh dương
        Chân dài nối với điện trở và nối với chân GPIO13
    - Button vàng
        Một chân nối với GPIO26 của ESP2
        Một chân nối với GND
'''
'''
Máy sấy tóc thông minh thông minh
    -DHT22
        Chân VCC của relay nối với nguồn 3v3 của ESP32
        Chân GND của relay nối với GND của ESP32
        Chân SDA của DHT22 nối với 25 của ESP32
    -Relay
        Chân VCC của relay nối với nguồn 3v3 của ESP32
        Chân GND của relay nối với GND của ESP32
        Chân IN của relay nối với GPIO16 của ESP32
    -Led xanh nước biển
        Chân dài nối với nguồn VCC
        Chân ngắn nối với NO của relay
    -Button xanh dương
        Một chân nối với GND của ESP32
        Một chân nối với GPIO18 của ESP32 
    
'''
'''
Quạt thông minh

    Dư: (- LED đỏ
        Chân dài nối với D của PIR
        Chân ngắn nối với GND của ESP32)
    -LED xanh lá cây 
        Chân dài nối với nguồn VCC
        Chân ngắn nối với NO của relay
   
    -Potentiometer
        VCC nối với 3v3 của ESP32
        GND nối với GND của ESP32
        SIG nối với chân GPIO34 của ESP32
    -Relay
        Chân VCC của relay nối với nguồn 3v3 của ESP32
        Chân GND của relay nối với GND của ESP32
        Chân IN của relay nối với GPIO2 của ESP32
    -Button đen
        Một chân nối với GND của ESP32
        Một chân nối với GPIO5 của ESP32 

'''
'''
Lò vi sóng thông minh
    - Led tím
        Chân dài nối với nguồn VCC
        Chân ngắn nối với NO của relay
    - Button đỏ
        Một chân nối với GPIO15 của ESP2
        Một chân nối với GND
    - Relay
        Chân VCC của relay nối với nguồn 3v3 của ESP32
        Chân GND của relay nối với GND của ESP32
        Chân IN của relay nối với GPIO4 của ESP32
'''

# Định nghĩa chân kết nối
led_xanh_duong_pin = 13  # Chân kết nối đèn LED
button_vang_pin = 26  # Chân kết nối nút nhấn

relay_Oven_pin = 4  # Chân kết nối Relay
led_hong_pin = 27
button_do_pin = 15  # Chân kết nối nút nhấn


# máy sấy tóc thông minh
chan_relay_may_say_toc = 16  # Chân relay máy sấy tóc
chan_led_nuoc = 21  # Chân LED xanh nước biển
button_xanh_duong_pin = 18

# Quạt thông minh
chan_led_xanh_la = 12  # Chân LED xanh lá (cho quạt)
chan_relay_quat = 2  # Chân relay quạt
button_đen_pin = 5

# Khởi tạo chân GPIO
led_xanh_duong = Pin(led_xanh_duong_pin, Pin.OUT)
button_vang = Pin(button_vang_pin, Pin.IN, Pin.PULL_UP)  # Sử dụng pull-up resistor

relay_Oven = Pin(relay_Oven_pin, Pin.OUT)
led_hong = Pin(led_hong_pin, Pin.OUT)
button_do = Pin(button_do_pin, Pin.IN, Pin.PULL_UP)  # Sử dụng pull-up resistor

relay_may_say_toc =Pin(chan_relay_may_say_toc, Pin.OUT)
button_xanh_duong =Pin(button_xanh_duong_pin, Pin.IN, Pin.PULL_UP)

relay_quat = Pin(chan_relay_quat, Pin.OUT)
button_đen =Pin(button_đen_pin,Pin.IN, Pin.OUT)
# máy sấy tóc
led_nuoc = Pin(chan_led_nuoc, Pin.OUT)

# Quạt thông minh
led_xanh_la = Pin(chan_led_xanh_la, Pin.OUT)



#Connect to Wifi
GLOB_WLAN=MOD_NETWORK.WLAN(MOD_NETWORK.STA_IF)
GLOB_WLAN.active(True)
GLOB_WLAN.connect("Wokwi-GUEST", "")

while not GLOB_WLAN.isconnected():
  pass



#Connect to Firebase
import ufirebase as firebase
firebase.setURL("https://iotp-4968f-default-rtdb.firebaseio.com/")


# Hàm đèn thông minh
def turnOnBlub():
    led_xanh_duong.value(1)
    time.sleep(0.5)

def turnOffBlub():
    led_xanh_duong.value(0)
    time.sleep(0.5)

def dieu_khien_den(is_on):
    if is_on:
        turnOnBlub
    else:
        turnOffBlub
    time.sleep(0.5)  

# Hàm quạt
def turnOnFan():
    relay_quat.value(1)
    led_xanh_la.value(1)
    time.sleep(0.5)

def turnOffFan():
    relay_quat.value(0)
    led_xanh_la.value(0)
    time.sleep(0.5)

def dieu_khien_quat(is_on):
    if is_on:
        turnOnFan()
    else:
        turnOffFan()

# Hàm điều khiển máy sấy tóc
def turnOnHairDryer():
    relay_may_say_toc.value(1)  # Bật Relay để mở máy sấy tóc
    led_nuoc.value(1)  # Bật LED xanh nước biển (nước đang chảy)
    time.sleep(0.5)   # Giữ trong 3 giây
    

def turnOffHairDryer():
    relay_may_say_toc.value(0)  # Tắt Relay để đóng máy sấy tóc
    led_nuoc.value(0)  # Tắt LED xanh nước biển (nước không chảy)
    time.sleep(0.5)   # Giữ trong 3 giây

def dieu_khien_may_say_toc(is_on):
    if is_on:
        turnOnHairDryer()
    else:
        turnOffHairDryer()

# Hàm oven
def open_Oven():
    relay_Oven.value(1)  # Bật Relay để mở oven
    led_hong.value(1)
    # time.sleep(3)   # Giữ trong 3 giây (thời gian mở oven)
    # relay_Oven.value(0)  # Tắt Relay

def close_Oven():
    relay_Oven.value(0)  # Bật Relay để đóng oven
    led_hong.value(0)

    # time.sleep(3)   # Giữ trong 3 giây (thời gian đóng oven)
    # relay_Oven.value(0)  # Tắt Relay

def dieu_khien_Oven(is_on):
    if is_on:
        open_Oven()
    else:
        close_Oven()

isBub = False
isOven = False
isHairDryer = False
isFan = False

def call_api():
    firebase.get("devices/c67fd620-9c53-11ef-babe-ef9aaf1bc254/isSelected","isBubStatus")
    isBub = firebase.isBubStatus
    if isBub:
        turnOnBlub()
    else:
        turnOffBlub()
    firebase.get("devices/21a879d0-9c54-11ef-babe-ef9aaf1bc254/isSelected","isOvenStatus")
    isOven = firebase.isOvenStatus
    if isOven:
        open_Oven()
    else:
        close_Oven()
    firebase.get("devices/15ce9220-9c54-11ef-babe-ef9aaf1bc254/isSelected","isHairDryerStatus")
    isHairDryer = firebase.isHairDryerStatus
    if isHairDryer: 
        turnOnHairDryer()
    else:
        turnOffHairDryer()
    firebase.get("devices/022a7ea0-9c54-11ef-babe-ef9aaf1bc254/isSelected","isFanStatus")
    isFan = firebase.isFanStatus
    if isFan:
        turnOnFan()
    else:
        turnOffFan()

while True:
    call_api()
    print("Get data successfull!")
    time.sleep(3)
    # for i in range(4):
    #     print(i + 1)
    if button_vang.value() == 0:  
        if isBub:
            turnOffBlub()
            isBub = False
            firebase.patch("devices/c67fd620-9c53-11ef-babe-ef9aaf1bc254", {"isSelected": isBub})
        else: 
            turnOnBlub()
            isBub = True  
            firebase.patch("devices/c67fd620-9c53-11ef-babe-ef9aaf1bc254", {"isSelected": isBub})
        # time.sleep(1)  

    elif button_do.value() == 0: 
        if isOven:
            close_Oven()
            isOven = False  
            firebase.patch("devices/21a879d0-9c54-11ef-babe-ef9aaf1bc254", {"isSelected": isOven})

        else:  
            open_Oven()
            isOven = True  
            firebase.patch("devices/21a879d0-9c54-11ef-babe-ef9aaf1bc254", {"isSelected": isOven})
        # time.sleep(0.5)  
    elif button_xanh_duong.value() ==0:
        if isHairDryer:
            turnOffHairDryer()
            isHairDryer = False
            firebase.patch("devices/15ce9220-9c54-11ef-babe-ef9aaf1bc254", {"isSelected": isHairDryer})
            
        else:
            turnOnHairDryer()
            isHairDryer =True
            firebase.patch("devices/15ce9220-9c54-11ef-babe-ef9aaf1bc254", {"isSelected": isHairDryer})
    elif button_đen.value()==0:
        if isFan :
            turnOffFan()
            isFan =False
            firebase.patch("devices/022a7ea0-9c54-11ef-babe-ef9aaf1bc254", {"isSelected": isHairDryer})
        else:
            turnOnFan()
            isFan =True
            firebase.patch("devices/022a7ea0-9c54-11ef-babe-ef9aaf1bc254", {"isSelected": isHairDryer})